
Shayla & Francesco — Static wedding website (multi-page)
-------------------------------------------------------

Contenuto del pacchetto:
- index.html (home)
- storia.html
- matrimonio.html
- rsvp.html (inserire iframe Google Forms nella pagina per raccogliere RSVP)
- galleria.html (sostituire segnaposto con immagini nella cartella images/)
- contatti.html
- styles.css
- script.js

Istruzioni rapide per pubblicare su GitHub Pages:
1. Vai su https://github.com e accedi con il tuo account (thomasshelby11).
2. Crea un nuovo repository pubblico chiamato: `shayla-francesco`.
3. Carica tutti i file da questa cartella (clicca "Add file" → "Upload files").
4. Vai su Settings → Pages e imposta la branch `main` (o `master`) come sorgente Pages, poi salva.
5. Il sito sarà disponibile su: https://<tuo-username>.github.io/shayla-francesco/

Per l'RSVP con Google Forms:
- Accedi con l'email saifmeddeb10@gmail.com a https://forms.google.com
- Crea il modulo e poi clicca su "Invia" → icona < > per incorporare l'iframe
- Copia il valore src e incollalo nel file rsvp.html sostituendo SRC_FORM_IFRAME

Se vuoi posso guidarti passo passo durante l'upload o darti i comandi Git se preferisci usare Git da terminale.
